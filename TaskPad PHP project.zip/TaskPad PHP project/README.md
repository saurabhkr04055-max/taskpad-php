TaskPad PHP (CIS 435 - Project 3) Alwaleed Aladalai

A minimal task tracker in plain PHP that persists tasks in a JSON file. Designed to match the CIS 435 Project 3 brief.

Quick start

1. Clone/copy files into a folder `taskpad-php`.
2. From project root run:
php -S localhost:8080 -t public
3. Open `http://localhost:8080/`

Structure
public/  web entry points and assets
src/  helpers: storage, validation, csrf, flash
data/  tasks.json (persisted)
tests/  test cases and runner
docs/  UML PlantUML sources


 Features
- Create task (server-side validation)
- List tasks with text + priority filter
- Mark complete / Delete (POST + CSRF token)
- Data persisted in `data/tasks.json`
- Simple test runner: `php tests/run_tests.php`

Run tests
php tests/run_tests.php

pgsql
This will run the sample cases in `tests/test_cases.json`. The runner simulates requests by including the endpoint files and checking headers/output.

Notes & recommendations
- This is intentionally minimal and dependency-free.
- For production use: avoid file-level concurrency issues (use DB or file locking), hardened session/cookie config, and stronger CSRF pattern.
- Expand `tests/test_cases.json` with more cases (invalid dates, concurrency, etc.).
